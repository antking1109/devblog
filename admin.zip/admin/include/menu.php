        <div class="be-left-sidebar">
            <div class="left-sidebar-wrapper"><a href="#" class="left-sidebar-toggle">Dashboard</a>
                <div class="left-sidebar-spacer">
                    <div class="left-sidebar-scroll">
                        <div class="left-sidebar-content">
                            <ul class="sidebar-elements">
                                <li class="divider">Menu</li>
                                <li class="active"><a href="../admin/options.php"><i class="icon mdi mdi-home"></i><span>Option</span></a>
                                </li>
                                <li class="active"><a href="../admin/manage_user.php"><i class="icon mdi mdi-face"></i><span>Manage User</span></a>
                                </li>
                                <li class="active"><a href="../admin/view_pages.php"><i class="icon mdi mdi-chart-donut"></i><span>View Pages</span></a>
                                </li>
                                <li class="active"><a href="../admin/add_pages.php"><i class="icon mdi mdi-dot-circle"></i><span>Add Pages</span></a>
                                </li>
                                <li class="active"><a href="../admin/view_categories.php"><i class="icon mdi mdi-border-all"></i><span>View Categories</span></a>
                                </li>
                                <li class="active"><a href="../admin/add_categories.php"><i class="icon mdi mdi-layers"></i><span>Add Categories</span></a>
                                </li>
                                <li class="divider">Manage File</li>
                                <li class="active"><a href="../admin/add_files.php"><i class="icon mdi mdi-inbox"></i><span>Add File</span></a>
                                </li>
                                <li class="active"><a href="../admin/view_files.php"><i class="icon mdi mdi-view-web"></i><span>View File</span></a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>