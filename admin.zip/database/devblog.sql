-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Máy chủ: 127.0.0.1
-- Thời gian đã tạo: Th1 24, 2018 lúc 11:34 AM
-- Phiên bản máy phục vụ: 10.1.28-MariaDB
-- Phiên bản PHP: 7.1.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Cơ sở dữ liệu: `devblog`
--

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `categories`
--

CREATE TABLE `categories` (
  `cat_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `cat_name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `position` tinyint(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `categories`
--

INSERT INTO `categories` (`cat_id`, `user_id`, `cat_name`, `position`) VALUES
(1, 1, 'About', 1),
(6, 1, 'Contant', 2),
(7, 1, 'Blog', 3);

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `comments`
--

CREATE TABLE `comments` (
  `comment_id` int(11) NOT NULL,
  `page_id` int(11) NOT NULL,
  `auther` varchar(60) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(60) COLLATE utf8_unicode_ci NOT NULL,
  `comment` text COLLATE utf8_unicode_ci NOT NULL,
  `comment_date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `comments`
--

INSERT INTO `comments` (`comment_id`, `page_id`, `auther`, `email`, `comment`, `comment_date`) VALUES
(16, 9, 'TrÆ°á»ng', 'congtruongvp97@gmail.com', 'Test comment', '2018-01-03 14:56:00'),
(17, 9, 'TrÆ°á»ng', 'congtruongvp97@gmail.com', 'Test comment', '2018-01-03 14:56:38'),
(18, 9, '1', '2@gma.c', '3', '2018-01-05 15:10:56'),
(19, 9, 'TrÆ°á»ng', 'concac@gmail.com', 'Test comment :v', '2018-01-07 16:45:31'),
(20, 9, 'TrÆ°á»ng', 'congtruong1109@gmail.com', 'test v2', '2018-01-07 16:47:36'),
(21, 9, 'TrÆ°á»ng', 'congtruong1109@gmail.com', 'test v2', '2018-01-07 16:49:17'),
(22, 9, 'TrÆ°á»ng', 'congtruong1109@gmail.com', 'test v5', '2018-01-07 16:50:51'),
(23, 9, 'TrÆ°á»ng', 'congtruong1109@gmail.com', 'test v5', '2018-01-07 16:53:05'),
(24, 9, 'TrÆ°á»ng', 'congtruong1109@gmail.com', 'test v5', '2018-01-07 16:53:13');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `files`
--

CREATE TABLE `files` (
  `file_id` int(11) NOT NULL,
  `name` text COLLATE utf32_unicode_ci NOT NULL,
  `upload_on` datetime NOT NULL,
  `size` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf32 COLLATE=utf32_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `files`
--

INSERT INTO `files` (`file_id`, `name`, `upload_on`, `size`) VALUES
(11, 'Screenshot (12).png', '2018-01-24 11:21:11', 117272),
(12, 'Screenshot (2).png', '2018-01-24 17:21:13', 139103);

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `options`
--

CREATE TABLE `options` (
  `option_id` int(11) NOT NULL,
  `option_name` varchar(200) COLLATE utf32_unicode_ci NOT NULL,
  `option_value` varchar(500) COLLATE utf32_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf32 COLLATE=utf32_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `options`
--

INSERT INTO `options` (`option_id`, `option_name`, `option_value`) VALUES
(1, 'siteurl', 'http://congtruong.xyz'),
(2, 'sitename', 'CÃ´ng TrÆ°á»ng Blog'),
(3, 'sitedescription', 'Blog Chia Sáº» Bá»Ÿi Tráº§n CÃ´ng TrÆ°á»ng');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `pages`
--

CREATE TABLE `pages` (
  `page_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `cat_id` int(11) NOT NULL,
  `page_name` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `content` text COLLATE utf8_unicode_ci NOT NULL,
  `position` tinyint(4) NOT NULL,
  `post_on` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `pages`
--

INSERT INTO `pages` (`page_id`, `user_id`, `cat_id`, `page_name`, `content`, `position`, `post_on`) VALUES
(3, 1, 1, 'CÃCH Sá»¬A Lá»–I â€œANOTHER UPDATE IN PROCESSâ€ TRONG WORDPRESS', 'Trong quÃ¡ trÃ¬nh cáº­p nháº­t theme hay plugin báº¡n thÆ°á»ng sáº½ bá»‹ lá»—i Another Update in Process. Lá»—i nÃ y táº¡m dá»‹ch lÃ  â€œMá»™t lá»—i cáº­p nháº­t khÃ¡c Ä‘ang Ä‘Æ°á»£c xá»­ lÃ½â€. NÃ³ sáº½ ngÄƒn báº¡n cáº­p nháº­t WordPress. vÃ  thÃ´ng thÆ°á»ng thÃ¬ nÃ³ sáº½ tá»± Ä‘á»™ng biáº¿n máº¥t. NhÆ°ng náº¿u khÃ´ng, thÃ¬ cÃ³ cÃ¡ch dá»… dÃ ng Ä‘á»ƒ sá»­a chá»¯a nÃ³. Trong bÃ i nÃ y, mÃ¬nh sáº½ chá»‰ cho báº¡n cÃ¡ch kháº¯c phá»¥c lá»—i â€œAnother Update in Processâ€ trong WordPress.\r\n\r\nTáº I SAO Xáº¢Y RA Lá»–I â€œANOTHER UPDATE IN PROCESSâ€?\r\n\r\nThÃ´ng bÃ¡o nÃ y thÆ°á»ng xuáº¥t hiá»‡n khi báº£n cáº­p nháº­t cá»‘t lÃµi cá»§a WordPress Ä‘ang cháº¡y áº©n vÃ  ngÆ°á»i dÃ¹ng cá»‘ gáº¯ng báº¯t Ä‘áº§u quÃ¡ trÃ¬nh cáº­p nháº­t khÃ¡c.\r\n\r\nTrong quÃ¡ trÃ¬nh cáº­p nháº­t cá»‘t lÃµi, WordPress sáº½ tá»± Ä‘á»™ng Ä‘áº·t má»™t khÃ³a cáº­p nháº­t tÃ¹y chá»n trong cÆ¡ sá»Ÿ dá»¯ liá»‡u . TÃ¹y chá»n cÆ¡ sá»Ÿ dá»¯ liá»‡u nÃ y ngÄƒn khÃ´ng cho báº¡n cháº¡y cÃ¡c báº£n cáº­p nháº­t Ä‘á»“ng thá»i trÃªn trang web cá»§a báº¡n.\r\n\r\nLoi-Another-Update in-Process\r\n\r\nThÃ´ng bÃ¡o nÃ y Ä‘Æ°á»£c Ä‘áº·t tá»± Ä‘á»™ng biáº¿n máº¥t trong 15 phÃºt hoáº·c khi quÃ¡ trÃ¬nh cáº­p nháº­t hoÃ n táº¥t. Tuy nhiÃªn, náº¿u báº¡n Ä‘ang máº¯c káº¹t trÃªn tin nháº¯n Ä‘Ã³ hoáº·c khÃ´ng muá»‘n Ä‘á»£i, thÃ¬ báº¡n cÃ³ thá»ƒ tá»± thiáº¿t láº­p láº¡i nÃ³.\r\n\r\nChÃºng ta hÃ£y xem cÃ¡ch sá»­a lá»—i Another Update in Process trong WordPress.\r\n\r\nSá»¬A Lá»–I ANOTHER UPDATE IN PROCESS TRÃŠN WORDPRESS\r\n\r\nÄá»ƒ thoÃ¡t khá»i tin nháº¯n â€˜Another Update in Processâ€™, báº¡n cáº§n pháº£i xoÃ¡ tÃ¹y chá»n core_updater.lock khá»i cÆ¡ sá»Ÿ dá»¯ liá»‡u WordPress cá»§a mÃ¬nh. MÃ¬nh sáº½ hÆ°á»›ng dáº«n cÃ¡c báº¡n lÃ m Ä‘iá»u Ä‘Ã³ báº±ng cÃ¡ch sá»­ dá»¥ng hai phÆ°Æ¡ng phÃ¡p khÃ¡c nhau. Báº¡n cÃ³ thá»ƒ chá»n cÃ¡ch mÃ  giÃºp báº¡n lÃ m viá»‡c nhanh nháº¥t.\r\n\r\nCÃCH 1: Sá»¬ Dá»¤NG PLUGIN Äá»‚ Sá»¬A Lá»–I â€˜ANOTHER UPDATE IN PROCESSâ€™\r\n\r\nÄáº§u tiÃªn báº¡n cáº§n cÃ i Ä‘áº·t Plugin Fix Another Update In Progress táº¡i link sau: Fix Another Update In Progress\r\n\r\nSau khi cÃ i Ä‘áº·t plugin cÃ¡c báº¡n vÃ o: Settings Â» Fix Another Update In Progress. Náº¿u cÃ¡c cáº­p nháº­t trÃªn trang web cá»§a báº¡n bá»‹ khÃ³a, thÃ¬ báº¡n sáº½ tháº¥y má»™t thÃ´ng bÃ¡o vá»›i má»™t nÃºt Ä‘á»ƒ sá»­a nÃ³ nhÆ° hÃ¬nh dÆ°á»›i:\r\n\r\nFix Another Update In Progress\r\n\r\nÄÆ¡n giáº£n chá»‰ cáº§n nháº¥p vÃ o nÃºt â€˜Fix WordPress Update Lockâ€™ Ä‘á»ƒ tiáº¿p tá»¥c.\r\n\r\nPlugin nÃ y sáº½ xÃ³a lá»±a chá»n khÃ³a báº£n cáº­p nháº­t WordPress tá»« cÆ¡ sá»Ÿ dá»¯ liá»‡u cá»§a báº¡n, vÃ  báº¡n sáº½ tháº¥y má»™t thÃ´ng bÃ¡o thÃ nh cÃ´ng nhÆ° sau:\r\n\r\nLoi-Another-Update in-Process-2\r\n\r\nCÃCH 2: Sá»¬ Dá»¤NG PHPMYADMIN Äá»‚ XÃ“A CORE_UPDATER.LOCK\r\n\r\nPhÆ°Æ¡ng phÃ¡p nÃ y yÃªu cáº§u báº¡n sá»­ dá»¥ng phpMyAdmin Ä‘á»ƒ cháº¡y trá»±c tiáº¿p má»™t truy váº¥n trong cÆ¡ sá»Ÿ dá»¯ liá»‡u WordPress cá»§a báº¡n.\r\n\r\nÄáº§u tiÃªn báº¡n cáº§n truy cáº­p vÃ o báº£ng Ä‘iá»u khiá»ƒn cPanel cá»§a tÃ i khoáº£n lÆ°u trá»¯ WordPress cá»§a báº¡n. Trong pháº§n cÆ¡ sá»Ÿ dá»¯ liá»‡u, nháº¥p vÃ o biá»ƒu tÆ°á»£ng phpMyAdmin.\r\n\r\nFix Another Update In Progress\r\n\r\nTiáº¿p theo báº¡n cáº§n pháº£i chá»n cÆ¡ sá»Ÿ dá»¯ liá»‡u WordPress trong phpMyAdmin. Äiá»u nÃ y sáº½ cho báº¡n tháº¥y táº¥t cáº£ cÃ¡c báº£ng bÃªn trong cÆ¡ sá»Ÿ dá»¯ liá»‡u WordPress cá»§a báº¡n. Báº¡n cáº§n pháº£i nháº¥p vÃ o nÃºt â€œBrowseâ€ bÃªn cáº¡nh báº£ng tÃ¹y chá»n wp_options.\r\n\r\nLoi-Another-Update in-Process-4\r\n\r\nÄiá»u nÃ y sáº½ hiá»ƒn thá»‹ cho báº¡n táº¥t cáº£ cÃ¡c hÃ ng bÃªn trong báº£ng wp_options. Báº¡n cáº§n tÃ¬m hÃ ng vá»›i tÃªn tÃ¹y chá»n â€œcore_updater.lockâ€ vÃ  nháº¥p vÃ o nÃºt â€œdeleteâ€ bÃªn cáº¡nh nÃ³.\r\n\r\nloi Another Update in Process\r\n\r\nPhpMyAdmin bÃ¢y giá» sáº½ xÃ³a core_updater.lock tá»« cÆ¡ sá»Ÿ dá»¯ liá»‡u WordPress cá»§a báº¡n. Báº¡n cÃ³ thá»ƒ chuyá»ƒn vá» trang web WordPress vÃ  tiáº¿p tá»¥c cáº­p nháº­t trang web WordPress cá»§a báº¡n. MÃ¬nh bÃ i viáº¿t nÃ y Ä‘Ã£ giÃºp báº¡n kháº¯c phá»¥c lá»—i Another Update in Process trÃªn trang WordPress cá»§a báº¡n.', 2, '2017-10-15 17:56:38'),
(4, 1, 1, 'HÆ¯á»šNG DáºªN KHÃ”I PHá»¤C Máº¬T KHáº¨U WORDPRESS', 'Báº¡n Ä‘Ã£ quÃªn máº­t kháº©u WordPress vÃ  bÃ¢y giá» muá»‘n khÃ´i phá»¥c láº¡i máº­t kháº©u bá»‹ máº¥t?. Báº¡n khÃ´ng pháº£i lo vÃ¬ bÃ i viáº¿t nÃ y mÃ¬nh sáº½ chá»‰ cho báº¡n cÃ¡ch khÃ´i phá»¥c máº­t kháº©u WordPress.\r\n\r\nCÃCH KHÃ”I PHá»¤C Máº¬T KHáº¨U WORDPRESS\r\n\r\nÄáº§u tiÃªn, báº¡n hÃ£y truy cáº­p vÃ o mÃ n hÃ¬nh Ä‘Äƒng nháº­p cá»§a blog WordPress cá»§a báº¡n.Trang Ä‘Äƒng nháº­p cá»§a blog WordPress cá»§a báº¡n máº·c Ä‘á»‹nh Ä‘Æ°á»£c Ä‘áº·t táº¡i http://domain.com/wp-admin/.\r\n\r\nThay tháº¿ domain.com báº±ng Ä‘á»‹a chá»‰ trang web cá»§a báº¡n. á»ž mÃ n hÃ¬nh Ä‘Äƒng nháº­p sáº½ cÃ³ pháº§n Báº¡n quÃªn máº­t kháº©u?, cÃ¡c báº¡n click vÃ o Ä‘Ã¢y.\r\n\r\nkhÃ´i phá»¥c máº­t kháº©u WordPress\r\n\r\nSau khi click, báº¡n sáº½ Ä‘Æ°á»£c Ä‘Æ°a Ä‘áº¿n trang khÃ¡c nÆ¡i báº¡n sáº½ Ä‘Æ°á»£c yÃªu cáº§u cung cáº¥p tÃªn ngÆ°á»i dÃ¹ng hoáº·c Ä‘á»‹a chá»‰ email WordPress cá»§a mÃ¬nh. CÃ¡c báº¡n nháº­p tÃªn tÃ i khoáº£n hoáº·c email vÃ o sau Ä‘Ã³ click vÃ o Láº¥y máº­t kháº©u má»›i.\r\n\r\nanh-dat-lai-mat-khau-2\r\n\r\nSau khi thá»±c hiá»‡n bÆ°á»›c trÃªn, WordPress sáº½ yÃªu cáº§u báº¡n kiá»ƒm tra email cá»§a báº¡n Ä‘á»ƒ láº¥y Ä‘Æ°á»ng dáº«n xÃ¡c nháº­n.\r\n\r\nanh-dat-lai-mat-khau-3\r\n\r\nLÃºc nÃ y báº¡n kiá»ƒm tra email cá»§a báº¡n sáº½ cÃ³ má»™t email má»›i vá»›i tiÃªu Ä‘á»: â€œ[TiÃªu Ä‘á» blog cá»§a báº¡n] Thiáº¿t láº­p láº¡i máº­t kháº©uâ€œ. Náº¿u báº¡n kiá»ƒm tra trong há»™p thÆ° Ä‘áº¿n khÃ´ng cÃ³ thÃ¬ cÃ¡c báº¡n nhá»› kiá»ƒm tra trong má»¥c Spam nha.\r\n\r\nEmail gá»­i vá» sáº½ cÃ³ ná»™i dung tÆ°Æ¡ng tá»± nhÆ° sau:\r\n\r\nMá»™t ai Ä‘Ã³ vá»«a yÃªu cáº§u Ä‘áº·t láº¡i máº­t kháº©u cho tÃ i khoáº£n sau:\r\nhttp://tenmiencuaban.com/\r\nTÃªn ngÆ°á»i dÃ¹ng: tentaikhaon\r\nNáº¿u Ä‘iá»u nÃ y lÃ  má»™t sai láº§m, chá»‰ cáº§n bá» qua email nÃ y vÃ  khÃ´ng cÃ³ gÃ¬ sáº½ xáº£y ra.\r\nÄá»ƒ thiáº¿t láº­p láº¡i máº­t kháº©u cá»§a báº¡n, hÃ£y truy cáº­p vÃ o Ä‘á»‹a chá»‰ sau Ä‘Ã¢y:\r\n<http://www.tenmiencuaban.com/wp-login.php?action=rp&key=xxxyyyzzz1112223&login=tentaikhoan>\r\nNháº¥p vÃ o liÃªn káº¿t thá»© hai Ä‘á»ƒ Ä‘áº·t láº¡i máº­t kháº©u. LiÃªn káº¿t nÃ y sáº½ Ä‘Æ°a báº¡n trá»Ÿ láº¡i trang web cá»§a báº¡n vÃ  sáº½ cho phÃ©p báº¡n nháº­p má»™t máº­t kháº©u má»›i cho tÃ i khoáº£n WordPress cá»§a báº¡n.\r\n\r\nanh-dat-lai-mat-khau-4\r\n\r\nWordPress sáº½ tá»± Ä‘á»™ng táº¡o ra má»™t máº­t kháº©u Ä‘á»§ máº¡nh cho báº¡n. Báº¡n cÃ³ thá»ƒ sá»­a láº¡i theo Ã½ cá»§a báº¡n. Thanh thÃ´ng bÃ¡o á»Ÿ dÆ°á»›i sáº½ cho báº¡n biáº¿t Ä‘á»™ máº¡nh cá»§a máº­t kháº©u mÃ  báº¡n Ä‘ang Ä‘áº·t. WordPress cho phÃ©p báº¡n thiáº¿t láº­p má»™t máº­t kháº©u yáº¿u, tuy nhiÃªn báº¡n váº«n nÃªn chá»n má»™t máº­t kháº©u máº¡nh. Khi báº¡n Ä‘Ã£ nháº­p máº­t kháº©u, báº¡n chá»n Thiáº¿t láº­p láº¡i máº­t kháº©u lÃ  thÃ nh cÃ´ng.\r\n\r\nKáº¾T LUáº¬N\r\n\r\nTrÃªn Ä‘Ã¢y lÃ  cÃ¡ch khÃ´i phá»¥c máº­t kháº©u WordPress khi báº¡n quÃªn. CÃ¡ch nÃ y hoáº¡t Ä‘á»™ng náº¿u há»‡ thá»‘ng email cá»§a website cá»§a báº¡n váº«n á»•n Ä‘á»‹nh. Tuy nhiÃªn, má»™t sá»‘ trÆ°á»ng há»£p báº¡n khÃ´ng thá»ƒ nháº­n Ä‘Æ°á»£c email thÃ¬ cÃ¡c báº¡n cÃ³ thá»ƒ láº¥y láº¡i máº­t kháº©u theo cÃ¡ch sau: CÃ¡ch Ä‘áº·t láº¡i máº­t kháº©u WordPress báº±ng phpMyAdmin.', 1, '2017-10-15 17:58:49'),
(5, 1, 1, 'SO SÃNH WORDPRESS.COM VÃ€ WORDPRESS.ORG', 'Báº¡n cÃ³ biáº¿t ráº±ng WordPress.com vÃ  WordPress.org thá»±c sá»± lÃ  hai ná»n táº£ng ráº¥t khÃ¡c nhau? NgÆ°á»i má»›i báº¯t Ä‘áº§u thÆ°á»ng nháº§m láº«n giá»¯a hai ná»n táº£ng khiáº¿n há» chá»n sai. Ráº¥t nhiá»u ngÆ°á»i há»i ráº±ng cÃ¡i nÃ o trong 2 ná»n táº£ng: WordPress.com vÃ  WordPress.org lÃ  tá»‘t nháº¥t. Äá»ƒ giÃºp tráº£ lá»i cÃ¢u há»i nÃ y, mÃ¬nh sáº½ so sÃ¡nh WordPress.com vÃ  WordPress.org má»™t cÃ¡ch toÃ n diá»‡n nháº¥t.\r\n\r\nMá»¥c Ä‘Ã­ch cá»§a bÃ i viáº¿t nÃ y nháº±m chá»‰ rÃµ sá»± khÃ¡c biá»‡t giá»¯a hai ná»n táº£ng WordPress.org vÃ  WordPress.com. Qua Ä‘Ã³ giÃºp cÃ¡c báº¡n cÃ³ thá»ƒ chá»n Ä‘Ãºng ná»n táº£ng cho nhu cáº§u cá»§a mÃ¬nh.\r\n\r\nwporgvswpcom\r\n\r\nSO SÃNH WORDPRESS.COM VÃ€ WORDPRESS.ORG\r\n\r\nCÃ¡ch tá»‘t nháº¥t Ä‘á»ƒ hiá»ƒu sá»± khÃ¡c biá»‡t giá»¯a WordPress.com vÃ  WordPress.org lÃ  hÃ£y xem chi tiáº¿t tá»«ng ná»n táº£ng.\r\n\r\nWORDPRESS.ORG\r\n\r\nWordPress.org hay cÃ²n gá»i lÃ  â€œWordPressâ€œ, lÃ  ná»n táº£ng trang web phá»• biáº¿n Ä‘Æ°á»£c nháº¥t nhiá»u ngÆ°á»i sá»­ dá»¥ng. ÄÃ³ lÃ  má»™t mÃ£ nguá»“n má»Ÿ vÃ  100% miá»…n phÃ­ cho báº¥t cá»© ai sá»­ dá»¥ng. Äá»ƒ sá»­ dá»¥ng WordPress.org thÃ¬ báº¡n cáº§n cÃ³ má»™t tÃªn miá»n vÃ  má»™t hosting.\r\n\r\nDÆ°á»›i Ä‘Ã¢y lÃ  Æ°u vÃ  nhÆ°á»£c Ä‘iá»ƒm cá»§a viá»‡c sá»­ dá»¥ng WordPress.org Ä‘á»ƒ xÃ¢y dá»±ng trang web hoáº·c blog cá»§a báº¡n.\r\n\r\nÆ¯U ÄIá»‚M Cá»¦A WORDPRESS.ORG\r\n\r\nVá»›i WordPress.org, báº¡n cÃ³ toÃ n quyá»n kiá»ƒm soÃ¡t trang web cá»§a mÃ¬nh. Báº¡n cÃ³ thá»ƒ lÃ m báº¥t cá»© Ä‘iá»u gÃ¬ báº¡n muá»‘n vÃ  tÃ¹y chá»‰nh nÃ³ náº¿u báº¡n cáº§n. DÆ°á»›i Ä‘Ã¢y lÃ  má»™t sá»‘ lá»£i Ã­ch cá»§a viá»‡c chá»n WordPress.org Ä‘á»ƒ xÃ¢y dá»±ng trang web cá»§a báº¡n vÃ  lÃ½ do táº¡i sao nÃ³ lÃ  sá»± lá»±a chá»n cá»§a nhiá»u blogger.\r\n\r\nHoÃ n toÃ n miá»…n phÃ­ vÃ  dá»… sá»­ dá»¥ng.\r\nBáº¡n cÃ³ toÃ n quyá»n kiá»ƒm soÃ¡t. Báº¡n sá»Ÿ há»¯u trang web cá»§a báº¡n vÃ  táº¥t cáº£ dá»¯ liá»‡u cá»§a nÃ³. Trang web cá»§a báº¡n sáº½ khÃ´ng bá»‹ ngá»«ng hoáº¡t Ä‘á»™ng vÃ¬ ai Ä‘Ã³ cho ráº±ng báº¡n lÃ m trÃ¡i vá»›i Ä‘iá»u khoáº£n dá»‹ch vá»¥ cá»§a há» (miá»…n lÃ  báº¡n khÃ´ng lÃ m Ä‘iá»u gÃ¬ Ä‘Ã³ báº¥t há»£p phÃ¡p).\r\nBáº¡n cÃ³ thá»ƒ thÃªm cÃ¡c plugin WordPress miá»…n phÃ­, tráº£ phÃ­ vÃ \r\nBáº¡n cÃ³ thá»ƒ tá»± thiáº¿t káº¿ giao diá»‡n trang web cá»§a báº¡n. Hoáº·c báº¡n cÃ³ thá»ƒ thÃªm báº¥t ká»³ theme WordPress miá»…n phÃ­ hoáº·c tráº£ phÃ­ nÃ o báº¡n muá»‘n. Báº¡n cÅ©ng cÃ³ thá»ƒ sá»­a Ä‘á»•i báº¥t cá»© thá»© gÃ¬ báº¡n muá»‘n.\r\nBáº¡n cÃ³ thá»ƒ kiáº¿m tiá»n tá»« trang web cá»§a báº¡n báº±ng cÃ¡ch cháº¡y cÃ¡c quáº£ng cÃ¡o cá»§a riÃªng báº¡n mÃ  khÃ´ng chia sáº» doanh thu vá»›i báº¥t ká»³ ai.\r\nBáº¡n cÃ³ thá»ƒ sá»­ dá»¥ng cÃ¡c cÃ´ng cá»¥ máº¡nh máº½ nhÆ° Google Analytics Ä‘á»ƒ phÃ¢n tÃ­ch vÃ  theo dÃµi lÆ°á»£ng truy cáº­p.\r\nBáº¡n cÃ³ thá»ƒ sá»­ dá»¥ng WordPress Ä‘á»ƒ táº¡o má»™t cá»­a hÃ ng trá»±c tuyáº¿n Ä‘á»ƒ bÃ¡n sáº£n pháº©m ká»¹ thuáº­t sá»‘ hoáº·c váº­t lÃ½, cháº¥p nháº­n thanh toÃ¡n báº±ng tháº» tÃ­n dá»¥ng vÃ  giao hÃ ng / váº­n chuyá»ƒn hÃ ng hoÃ¡ trá»±c tiáº¿p tá»« trang web cá»§a báº¡n.\r\nNHÆ¯á»¢C ÄIá»‚M Cá»¦A WORDPRESS.ORG\r\n\r\nCÃ³ ráº¥t Ã­t khuyáº¿t Ä‘iá»ƒm khi sá»­ dá»¥ng WordPress.org. CÃ³ má»™t vÃ i Ä‘iá»ƒm yáº¿u cáº§n ká»ƒ Ä‘áº¿n:\r\n\r\nGiá»‘ng nhÆ° táº¥t cáº£ cÃ¡c trang web khÃ¡c, báº¡n sáº½ cáº§n cÃ³ web hosting. ÄÃ¢y lÃ  nÆ¡i lÆ°u trá»¯ cÃ¡c tá»‡p tin trong trang web cá»§a báº¡n trÃªn internet. Ban Ä‘áº§u, chi phÃ­ khoáº£ng 50.000 VND â€“ 200.000 VND  má»—i thÃ¡ng. Tuy nhiÃªn, khi trang web cá»§a báº¡n phÃ¡t triá»ƒn vÃ  cÃ³ nhiá»u lÆ°u lÆ°á»£ng truy cáº­p hÆ¡n, chi phÃ­ lÆ°u trá»¯ web sáº½ tÄƒng lÃªn, nhÆ°ng sau Ä‘Ã³ báº¡n sáº½ kiáº¿m Ä‘Æ°á»£c Ä‘á»§ tiá»n Ä‘á»ƒ trang tráº£i chi phÃ­.\r\nBáº¡n cÃ³ trÃ¡ch nhiá»‡m pháº£i cáº­p nháº­t khi cÃ³ phiÃªn báº£n má»›i. Báº¡n cÃ³ thá»ƒ dá»… dÃ ng cáº­p nháº­t trang WordPress cá»§a mÃ¬nh báº±ng cÃ¡ch nháº¥p vÃ o nÃºt cáº­p nháº­t (1 láº§n nháº¥p chuá»™t). Do Ä‘Ã³, viá»‡c nÃ y khÃ´ng pháº£i lÃ  khÃ³ khÄƒn vá»›i cÃ¡c báº¡n.\r\nBáº¡n cÃ³ trÃ¡ch nhiá»‡m sao lÆ°u website cá»§a mÃ¬nh. Tuy nhiÃªn, hiá»‡n cÃ³ ráº¥t nhiá»u plugin giÃºp chÃºng ta sao lÆ°u tá»± Ä‘á»™ng.\r\nChi phÃ­ thá»±c sá»± cá»§a trang WordPress.org thay Ä‘á»•i dá»±a trÃªn má»¥c Ä‘Ã­ch cá»§a (blog Ä‘Æ¡n giáº£n, cá»­a hÃ ng thÆ°Æ¡ng máº¡i Ä‘iá»‡n tá»­, website cÃ´ng tyâ€¦). NgoÃ i ra cÃ²n cÃ³ cÃ¡c yáº¿u tá»‘ khÃ¡c nhÆ° theme miá»…n phÃ­ hay theme báº£n quyá»n, plugin miá»…n phÃ­ hay plugin báº£n quyá»nâ€¦\r\n\r\nWORDPRESS.COM\r\n\r\nWordPress.com lÃ  má»™t dá»‹ch vá»¥ lÆ°u trá»¯ Ä‘Æ°á»£c táº¡o ra bá»Ÿi Ä‘á»“ng sÃ¡ng láº­p cá»§a WordPress, Matt Mullenweg. VÃ¬ cÃ¹ng má»™t ngÆ°á»i sÃ¡ng láº­p nÃªn ngÆ°á»i dÃ¹ng thÆ°á»ng nháº§m WordPress.com vá»›i pháº§n má»m WordPress.org phá»• biáº¿n.\r\n\r\nDá»‹ch vá»¥ lÆ°u trá»¯ WordPress.com cÃ³ â€‹â€‹5 gÃ³i:\r\n\r\nFree: Ráº¥t háº¡n cháº¿.\r\nPersonal: $36 / nÄƒm\r\nPremium: $99 / nÄƒm\r\nBusiness: $299 / nÄƒm\r\nVIP: Báº¯t Ä‘áº§u tá»« $5000 / thÃ¡ng\r\nChÃºng ta hÃ£y xem nhá»¯ng Æ°u vÃ  nhÆ°á»£c Ä‘iá»ƒm cá»§a WordPress.com.\r\n\r\nÆ¯U ÄIá»‚M Cá»¦A WORDPRESS.COM\r\n\r\nNá»n táº£ng miá»…n phÃ­ WordPress.com lÃ  má»™t lá»±a chá»n tá»‘t cho cÃ¡c blogger lÃ m Ä‘á»ƒ giáº£i trÃ­ vÃ  nhá»¯ng ngÆ°á»i báº¯t Ä‘áº§u má»™t blog cho gia Ä‘Ã¬nh cá»§a há». DÆ°á»›i Ä‘Ã¢y lÃ  má»™t sá»‘ lá»£i Ã­ch cá»§a viá»‡c sá»­ dá»¥ng WordPress.com:\r\n\r\nMiá»…n phÃ­ tá»‘i Ä‘a 3 GB dung lÆ°á»£ng lÆ°u trá»¯. Sau Ä‘Ã³ báº¡n sáº½ pháº£i chuyá»ƒn sang má»™t gÃ³i tráº£ tiá»n Ä‘á»ƒ cÃ³ thÃªm dung lÆ°á»£ng.\r\nBáº¡n sáº½ khÃ´ng pháº£i lo láº¯ng vá» viá»‡c cáº­p nháº­t phiÃªn báº£n hoáº·c sao lÆ°u website. WordPress.com sáº½ giáº£i quyáº¿t váº¥n Ä‘á» Ä‘Ã³.\r\nNHÆ¯á»¢C ÄIá»‚M Cá»¦A WORDPRESS.COM\r\n\r\nCÃ³ má»™t sá»‘ háº¡n cháº¿ cá»§a WordPress.com, Ä‘Ã¢y lÃ  Ä‘iá»ƒm Ä‘á»ƒ phÃ¢n biá»‡t nÃ³ vá»›i WordPress.org. DÆ°á»›i Ä‘Ã¢y lÃ  má»™t sá»‘ nhÆ°á»£c Ä‘iá»ƒm cá»§a viá»‡c sá»­ dá»¥ng WordPress.com:\r\n\r\nHá» Ä‘áº·t quáº£ng cÃ¡o trÃªn táº¥t cáº£ cÃ¡c trang web miá»…n phÃ­. VÃ¬ váº­y, ngÆ°á»i dÃ¹ng cá»§a báº¡n sáº½ nhÃ¬n tháº¥y quáº£ng cÃ¡o, vÃ  báº¡n khÃ´ng kiáº¿m Ä‘Æ°á»£c tiá»n tá»« nÃ³. Náº¿u báº¡n khÃ´ng muá»‘n ngÆ°á»i dÃ¹ng xem quáº£ng cÃ¡o cá»§a há» thÃ¬ báº¡n cÃ³ thá»ƒ nÃ¢ng cáº¥p lÃªn má»™t gÃ³i tráº£ tiá»n (báº¯t Ä‘áº§u tá»« gÃ³i  $36 má»—i nÄƒm).\r\nBáº¡n khÃ´ng Ä‘Æ°á»£c phÃ©p cháº¡y quáº£ng cÃ¡o trÃªn website cá»§a báº¡n. Náº¿u trang web cá»§a báº¡n cÃ³ lÆ°á»£ng truy cáº­p cao, thÃ¬ báº¡n cÃ³ thá»ƒ Ä‘Äƒng kÃ½ chÆ°Æ¡ng trÃ¬nh quáº£ng cÃ¡o cá»§a há» cÃ³ tÃªn WordAds. Nhá»¯ng ngÆ°á»i sá»­ dá»¥ng GÃ³i Premium vÃ  Business cÃ³ thá»ƒ sá»­ dá»¥ng WordAds ngay láº­p tá»©c.\r\nBáº¡n khÃ´ng thá»ƒ táº£i plugin. NgÆ°á»i dÃ¹ng gÃ³i Business cÃ³ thá»ƒ cÃ i Ä‘áº·t tá»« má»™t sá»‘ plugin bá»• sung. GÃ³i VIP cho phÃ©p báº¡n cÃ i Ä‘áº·t plugin,.\r\nBáº¡n khÃ´ng thá»ƒ táº£i lÃªn cÃ¡c chá»§ Ä‘á» tÃ¹y chá»‰nh. NgÆ°á»i sá»­ dá»¥ng gÃ³i miá»…n phÃ­ chá»‰ cÃ³ thá»ƒ cÃ i Ä‘áº·t tá»« bá»™ sÆ°u táº­p cÃ¡c chá»§ Ä‘á» miá»…n phÃ­. NgÆ°á»i sá»­ dá»¥ng gÃ³i Personal, Premium má»›i cÃ³ thá»ƒ lá»±a chá»n cÃ¡c chá»§ Ä‘á» cao cáº¥p. Nhá»¯ng ngÆ°á»i sá»­ dá»¥ng GÃ³i Premium vÃ  Business cÃ³ thá»ƒ tÃ¹y chá»‰nh CSS.\r\nBáº¡n buá»™c pháº£i sá»­ dá»¥ng sá»‘ liá»‡u thá»‘ng kÃª cá»§a há». Báº¡n khÃ´ng thá»ƒ thÃªm Google Analytics hoáº·c cÃ i Ä‘áº·t báº¥t ká»³ ná»n táº£ng theo dÃµi máº¡nh máº½ khÃ¡c. NgÆ°á»i dÃ¹ng káº¿ hoáº¡ch Business cÃ³ thá»ƒ cÃ i Ä‘áº·t Google Analytics.\r\nHá» cÃ³ thá»ƒ xÃ³a trang web cá»§a báº¡n báº¥t cá»© lÃºc nÃ o náº¿u há» nghÄ© ráº±ng báº¡n vi pháº¡m Äiá»u khoáº£n dá»‹ch vá»¥ cá»§a há».\r\nTrang web cá»§a báº¡n sáº½ hiá»ƒn thá»‹ má»™t liÃªn káº¿t Ä‘Æ°á»£c há»— trá»£ bá»Ÿi WordPress.com. NÃ³ cÃ³ thá»ƒ Ä‘Æ°á»£c gá»¡ bá» báº±ng cÃ¡ch nÃ¢ng cáº¥p lÃªn káº¿ hoáº¡ch kinh doanh.\r\nWordPress.com khÃ´ng cung cáº¥p báº¥t ká»³ tÃ­nh nÄƒng ThÆ°Æ¡ng máº¡i Äiá»‡n tá»­ nÃ o hoáº·c cá»•ng thanh toÃ¡n.\r\nKáº¾T LUáº¬N\r\n\r\nNÃ³i láº¡i váº¥n Ä‘á» so sÃ¡nh WordPress.com vÃ  WordPress.org. NhÆ° cÃ¡c báº¡n tháº¥y á»Ÿ trÃªn, ná»n táº£ng lÆ°u trá»¯ WordPress.com khÃ¡ háº¡n cháº¿ khi báº¡n sá»­ dá»¥ng gÃ³i miá»…n phÃ­, Personal hoáº·c tháº­m chÃ­ lÃ  Premium. Äá»ƒ má»Ÿ khÃ³a má»™t sá»‘ tÃ­nh nÄƒng nÃ¢ng cao hÆ¡n, báº¡n pháº£i sá»­ dá»¥ng gÃ³i Business ($299 / nÄƒm) hoáº·c VIP ($5000 / thÃ¡ng).\r\n\r\nNáº¿u báº¡n lÃ  má»™t blogger cÃ¡ nhÃ¢n, vÃ  báº¡n khÃ´ng quan tÃ¢m Ä‘áº¿n viá»‡c kiáº¿m tiá»n tá»« trang web cá»§a báº¡n, báº¡n cÃ³ thá»ƒ chá»n WordPress.com\r\n\r\nNáº¿u báº¡n lÃ  doanh nghiá»‡p hoáº·c má»™t blogger muá»‘n kiáº¿m tiá»n tá»« trang web cá»§a báº¡n, thÃ¬ chÃºng tÃ´i khuyÃªn báº¡n nÃªn sá»­ dá»¥ng WordPress.org. NÃ³ cho báº¡n sá»± tá»± do vÃ  sá»± linh hoáº¡t Ä‘á»ƒ phÃ¡t triá»ƒn trang web theo cÃ¡ch báº¡n muá»‘n.', 4, '2017-10-15 17:59:18'),
(6, 1, 1, 'HÆ¯á»šNG DáºªN CÃ€I Äáº¶T WORDPRESS LÃŠN HOSTING Äá»‚ Táº O Má»˜T WEBSITE Má»šI', 'CMS mÃ£ nguá»“n má»Ÿ giÃºp chÃºng ta táº¡o website miá»…n phÃ­. CÃ¡c báº¡n cÃ³ thá»ƒ táº¡o website hoÃ n toÃ n miá»…n phÃ­ vá»›i WordPress.com. Tuy nhiÃªn trong má»™t sá»‘ trÆ°á»ng há»£p náº¿u cÃ¡c báº¡n Ä‘Ã£ cÃ³ hosting vÃ  tÃªn miá»n riÃªng mÃ  muá»‘n sá»­ dá»¥ng WordPress.org Ä‘á»ƒ lÃ m website. Do váº­y bÃ i viáº¿t nÃ y mÃ¬nh sáº½ hÆ°á»›ng dáº«n cÃ¡c báº¡n cÃ¡ch cÃ i Ä‘áº·t WordPress lÃªn hosting Ä‘á»ƒ táº¡o má»™t website má»›i.\r\n\r\nCÃCH 1: CÃ€I Äáº¶T WORDPRESS Tá»° Äá»˜NG\r\n\r\nHiá»‡n nay háº§u háº¿t cÃ¡c nhÃ  cung cáº¥p hosting sá»­ dá»¥ng cPanel Ä‘á»ƒ quáº£n lÃ½. Trong cPanel sáº½ cÃ³ má»¥c SOFTACULOUS APP INSTALLER, trong má»¥c nÃ y cÃ³ pháº§n cÃ i Ä‘áº·t tá»± Ä‘á»™ng WordPress.\r\n\r\nÄáº§u tiÃªn cÃ¡c báº¡n Ä‘Äƒng nháº­p vÃ o panel cá»§a hosting, tÃ¬m tá»›i má»¥c SOFTACULOUS APP INSTALLER sau Ä‘Ã³ chá»n á»©ng dá»¥ng WordPress nhÆ° áº£nh dÆ°á»›i.\r\n\r\ncach cai dat wordpress\r\n\r\nTiáº¿p theo chá»n Install Now\r\n\r\ncach cai dat wordpess\r\n\r\nBÆ°á»›c tiáº¿p theo cÃ¡c báº¡n cÃ¢n khai bÃ¡o thÃ´ng tin Ä‘á»ƒ cÃ i Ä‘áº·t website WordPress. Trong má»¥c Software Setup cÃ³ cÃ¡c má»¥c sau:\r\n\r\nChoose Protocol: CÃ¡c báº¡n Ä‘á»ƒ máº·c Ä‘á»‹nh lÃ  http:// náº¿u báº¡n nÃ o mua chá»©ng chá»‰ SSL rá»“i thÃ¬ chá»n https://\r\nChoose Domain: Chá»n tÃªn miá»n báº¡n muá»‘n cÃ i WordPress\r\nIn Directory: Äá»ƒ trá»‘ng náº¿u báº¡n muá»‘n cÃ i Ä‘áº·t WordPress vÃ o http://tenmiencuaban/. Hoáº·c náº¿u báº¡n muá»‘n cÃ i Ä‘áº·t WordPress vÃ o thÆ° má»¥c nÃ o Ä‘Ã³ thÃ¬ nháº­p tÃªn thÆ° má»¥c vÃ o. VÃ­ dá»¥ muá»‘n cÃ i WordPress vÃ o thÆ° má»¥c WP thÃ¬ viáº¿t WP vÃ o vÃ  muá»‘n cháº¡y website thÃ¬ pháº£i truy cáº­p vÃ o http://tenmiencuaban/WP/.\r\nMá»¥c Site Settings thÃ¬ cÃ¡c báº¡n Ä‘iá»n tÃªn website cá»§a báº¡n vÃ o Site Name, mÃ´ táº£ website cá»§a báº¡n vÃ o Site Description cÃ²n má»¥c Enable Multisite (WPMU)  Ä‘á»ƒ nguyÃªn.\r\n\r\ncÃ¡ch cÃ i Ä‘áº·t wordpress\r\n\r\nCÃ¡c má»¥c Admin Account cÃ¡c báº¡n nháº­p vÃ o tÃªn Ä‘Äƒng nháº­p vÃ  máº­t kháº©u trang quáº£n trá»‹ WordPress cÃ²n Admin Email lÃ  Ä‘á»‹a chá»‰ email cá»§a báº¡n. Má»¥c Choose Language cÃ¡c báº¡n chá»n ngÃ´n ngá»¯ cho WordPress, á»Ÿ Ä‘Ã¢y cÃ³ há»— trá»£ tiáº¿ng Viá»‡t.\r\n\r\ncach cai dat wordpress\r\n\r\nCÃ¡c má»¥c cÃ²n láº¡i cÃ¡c báº¡n Ä‘á»ƒ nguyÃªn, cÃ²n náº¿u muá»‘n tá»± Ä‘áº·t tÃªn khÃ¡c cho database thÃ¬ sá»­a trong má»¥c Advanced Options. Cuá»‘c cÃ¹ng cÃ¡c báº¡n chá»n má»™t theme báº¥t ká»³ mÃ¬nh thÃ­ch trong má»¥c Select Theme rá»“i chá»n Install Ä‘á»ƒ cÃ i Ä‘áº·t.\r\n\r\nCÃCH 2: CÃ€I Äáº¶T WORDPRESS THá»¦ CÃ”NG QUA FTP\r\n\r\nÄáº§u tiÃªn cÃ¡c báº¡n cáº§n táº£i vá» phiÃªn báº£n má»›i nháº¥t cá»§a WordPress táº¡i https://wordpress.org/latest.zip. Sau khi táº£i vá» giáº£i nÃ©n ra ta Ä‘Æ°á»£c thÆ° má»¥c wordpress.\r\n\r\nBÆ°á»›c tiáº¿p theo cÃ¡c báº¡n cáº§n truy cáº­p vÃ o trang panel cá»§a hosting táº¡o má»™t database vÃ  má»™t database user. Sau Ä‘Ã³ thÃªm database user vÃ o database vÃ  cáº¥p má»i quyá»n cho nÃ³.\r\n\r\nTiáº¿p theo, chÃºng ta truy cáº­p vÃ o hosting thÃ´ng qua FTP vÃ  upload toÃ n bá»™ mÃ£ nguá»“n WordPress cÃ³ trong thÆ° má»¥c wordpress giáº£i nÃ©n á»Ÿ trÃªn vÃ o thÆ° má»¥c public_html cá»§a website. LÆ°u Ã½: Upload cÃ¡c file trong thÆ° má»¥c wordpress chá»© khÃ´ng upload cáº£ thÆ° má»¥c nha.\r\n\r\ncai wordpress cho hosting\r\n\r\nSau khi upload xong cÃ¡c báº¡n truy cáº­p vÃ o website cá»§a mÃ¬nh. LÃºc nÃ y nÃ³ sáº½ hiá»‡n ra má»¥c chá»n ngÃ´n ngá»¯, cÃ¡c báº¡n chá»n ngÃ´n ngá»¯ muá»‘n cÃ i Ä‘áº·t cho WordPress rá»“i áº¥n Continue. Tiáº¿p theo Ä‘Ã³ nÃ³ sáº½ hiá»‡n form Ä‘iá»n thÃ´ng tin database cá»§a báº¡n nhÆ° áº£nh dÆ°á»›i. LÆ°u Ã½ má»¥c tiá»n tá»‘ dá»¯ liá»‡u cÃ¡c báº¡n nÃªn thay wp_ báº±ng má»™t cÃ¡i tÃªn khÃ¡c vÃ­ dá»¥ nhÆ° tk_ Ä‘á»ƒ báº£o máº­t tá»‘t hÆ¡n. Sau Ä‘Ã³ áº¥n Gá»­i, á»Ÿ áº£nh dÆ°á»›i mÃ¬nh cÃ i trÃªn localhost nÃªn mÃ¬nh Ä‘á»n váº­y cÃ²n cÃ¡c báº¡n Ä‘iá»n thÃ´ng tin database giá»‘ng vá»›i lÃºc cÃ¡c báº¡n táº¡o.\r\n\r\ncach cai dat wordpress\r\n\r\nCuá»‘i cÃ¹ng lÃ  bÆ°á»›c Ä‘iá»n thÃ´ng tin website cá»§a báº¡n vÃ  thÃ´ng tin Ä‘Äƒng nháº­p quáº£n trá»‹ thÃ¬ mÃ¬nh cÅ©ng khÃ´ng cáº§n nÃ³i ná»¯a. Sau khi hoÃ n táº¥t, cÃ¡c báº¡n Ä‘Äƒng nháº­p vÃ o giao diá»‡n quáº£n lÃ½ sáº½ giá»‘ng nhÆ° hÃ¬nh dÆ°á»›i Ä‘Ã¢y.\r\n\r\ncach cai dat wordpress\r\n\r\nKáº¾T LUáº¬N\r\n\r\nNhÆ° váº­y mÃ¬nh Ä‘Ã£ hÆ°á»›ng dáº«n cÃ¡c báº¡n cÃ¡ch cÃ i Ä‘áº·t WordPress trÃªn hosting. Náº¿u báº¡n nÃ o cÃ²n khÃ³ khÄƒn chá»— nÃ o cÃ³ thá»ƒ comment bÃªn dÆ°á»›i Ä‘á»ƒ mÃ¬nh há»— trá»£. ChÃºc cÃ¡c báº¡n thÃ nh cÃ´ng!', 1, '2017-10-15 18:00:02'),
(7, 1, 1, 'CÃ“ GÃŒ Má»šI TRONG PHIÃŠN Báº¢N WORDPRESS 4.8', 'HÃ´m qua, WordPress Ä‘Ã£ ra máº¯t phiÃªn báº£n 4.8 â€“ má»™t phiÃªn báº£n chÃ­nh thá»©c Ä‘áº§u tiÃªn trong nÄƒm 2017. ChÃºng ta cÃ¹ng Ä‘iá»ƒm qua má»™t sá»‘ tÃ­nh nÄƒng má»›i cÃ³ trong phiÃªn báº£n WordPress 4.8 nÃ y nha.\r\n\r\nCÃC TIá»†N ÃCH WIDGET Má»šI\r\n\r\nCÃ³ ba widget má»›i Ä‘Æ°á»£c thÃªm vÃ o WordPress 4.8 theo nhÆ° mong Ä‘á»£i cá»§a nhiá»u ngÆ°á»i dÃ¹ng Ä‘Ã³ lÃ : Image Widget, Video Widget, Audio Widget.\r\n\r\n1. IMAGE WIDGET\r\n\r\nTrÆ°á»›c Ä‘Ã¢y náº¿u báº¡n muá»‘n thÃªm má»™t bá»©c áº£nh vÃ o widget (thanh bÃªn) thÃ¬ báº¡n cáº§n pháº£i upload áº£nh, sau Ä‘Ã³ thÃªm mÃ£ HTML.\r\n\r\nHiá»‡n táº¡i vá»›i WordPress 4.8 báº¡n chá»‰ cáº§n chá»n áº¢nh hay Image náº¿u dÃ¹ng tiáº¿ng Anh, sau Ä‘Ã³ chá»n vá»‹ trÃ­ hiá»ƒn thá»‹.\r\n\r\nanh-image-widget\r\n\r\nSau khi chá»n xong chÃºng ta chá»‰ cáº§n thÃªm áº£nh, tiÃªu Ä‘á» vÃ  lÆ°u láº¡i.\r\n\r\nanh-image-widget-1\r\n\r\nVá»›i tiá»‡n Ã­ch Image Widget má»›i Ä‘Æ°á»£c thÃªm nÃ y, mÃ¬nh tháº¥y nÃ³ tiá»‡n hÆ¡n ráº¥t nhiá»u so vá»›i viá»‡c pháº£i up áº£nh sau Ä‘Ã³ thÃªm code HTML nhÆ° trÆ°á»›c.\r\n\r\n2. VIDEO WIDGET\r\n\r\nCÅ©ng tÆ°Æ¡ng tá»± nhÆ° Image Widget, WordPress 4.8 cho phÃ©p chÃºng ta dá»… dÃ ng hiá»ƒn thá»‹ video lÃªn thanh bÃªn WordPress. Báº¡n cÃ³ thá»ƒ upload video lÃªn hoáº·c chÃ¨n link video tá»« Youtube, Vimeo hay báº¥t ká»³ cÃ¡c trang máº¡ng xÃ£ há»™i chia sáº» video nÃ o khÃ¡c. MÃ¬nh khuyáº¿n cÃ¡o cÃ¡c báº¡n khÃ´ng nÃªn upload video lÃªn website vÃ¬ nÃ³ ráº¥t tá»‘n dung lÆ°á»£ng.', 6, '2017-10-15 18:00:50'),
(8, 1, 1, 'Táº¶NG TRá»ŒN Bá»˜ THEME VÃ€ PLUGIN Táº I MYTHEMESHOP UPDATE ', 'Mythemeshop haiá»‡n Ä‘ang lÃ  má»™t trong nhá»¯ng nhÃ  cung cáº¥p theme vÃ  plugin WordPress lá»›n vÃ  tá»‘t nháº¥t hiá»‡n nay. Vá»›i hÆ¡n 300.000 khÃ¡ch hÃ ng, 141 theme vÃ  plugin Ä‘Ã£ cho ta tháº¥y vá»‹ trÃ­ cá»§a Mythemeshop trÃªn thá»‹ trÆ°á»ng.\r\n\r\nmythemeshop\r\n\r\nBáº¡n Ä‘ang sá»­ dá»¥ng WordPress, báº¡n Ä‘ang muá»‘n tÃ¬m má»™t theme Ä‘áº¹p cho website WordPress cá»§a mÃ¬nh? Mythemeshop sáº½ Ä‘Ã¡p á»©ng Ä‘á»§ nhu cáº§u cá»§a báº¡n vá»›i cÃ¡c chá»§ Ä‘á» khÃ¡c nhau:\r\n\r\nBlog: 50 theme\r\nBusiness: 16 theme\r\neCommerce: 15 theme\r\nFree: 17 theme\r\nMagazine: 41 theme\r\nPopular: 14 theme\r\n29 Plugin\r\nCon sá»‘ trÃªn Ä‘Æ°á»£c tÃ­nh táº¡i thá»i Ä‘iá»ƒm mÃ¬nh viáº¿t bÃ i viáº¿t nÃ y. GiÃ¡ má»—i má»™t theme lÃªn Ä‘áº¿n $89, hoáº·c báº¡n cÅ©ng cÃ³ thá»ƒ mua táº¥t cáº£ theme vÃ  plugin vá»›i giÃ¡ $167/nÄƒm. Tuy nhiÃªn, bÃ i viáº¿t nÃ y mÃ¬nh sáº½ chia sáº» miá»…n phÃ­ cho cÃ¡c báº¡n full theme vÃ  plugin cá»§a Mythemeshop. TrÆ°á»›c khi tham gia chÆ°Æ¡ng trÃ¬nh táº·ng theme miá»…n phÃ­ cá»§a mÃ¬nh, cÃ¡c báº¡n Ä‘á»c qua nhá»¯ng Ä‘iá»ƒm ná»•i báº­t cá»§a Mythemeshop Ä‘Ã£ nha.\r\n\r\nTáº I SAO NÃŠN Sá»¬ Dá»¤NG THEME Táº I MYTHEMESHOP\r\n\r\nDÆ°á»›i Ä‘Ã¢y lÃ  nhá»¯ng Ä‘iá»ƒm ná»•i báº­t cá»§a Mythemeshop khiáº¿n nhiá»u ngÆ°á»i sá»­ dá»¥ng. Hiá»‡n táº¡i blog cá»§a mÃ¬nh cÅ©ng Ä‘ang sá»­ dá»¥ng theme MyBlog cá»§a Mythemeshop.\r\n\r\nThiáº¿t káº¿ Responsive: GiÃºp trang web cá»§a báº¡n hoáº¡t Ä‘á»™ng tá»‘t trÃªn cÃ¡c thiáº¿t bá»‹ di Ä‘á»™ng vÃ  mÃ¡y tÃ­nh báº£ng, giÃºp cho Google Ä‘Ã¡nh giÃ¡ cao hÆ¡n vá» website cá»§a báº¡n.\r\nCÃ³ Theme Options: Táº¥t cáº£ cÃ¡c theme Ä‘á»u cÃ³ báº£ng tÃ¹y chá»n giÃºp báº¡n dá»… dÃ ng tÃ¹y chá»‰nh trang web cá»§a mÃ¬nh. Trong báº£ng tÃ¹y chá»‰nh cÃ²n cÃ³ chá»©c nÄƒng cÃ i Ä‘áº·t website giá»‘ng vá»›i demo chá»‰ vá»›i 1 click.\r\nTá»‘i Æ°u SEO: ÄÃ¢y lÃ  má»™t yáº¿u tá»‘ quan trá»ng khi lá»±a chá»n theme, nÃ³ giÃºp nháº¥t nhiá»u cho thá»© háº¡ng website cá»§a báº¡n.\r\nÄa nÄƒng: CÃ³ má»™t sá»‘ theme báº¡n cÃ³ thá»ƒ tÃ¹y biáº¿n trong báº£ng tÃ¹y chá»n cá»§a theme Ä‘á»ƒ táº¡o ra cÃ¡c giao diá»‡n khÃ¡c nhau tÃ¹y vÃ o má»¥c Ä‘Ã­ch sá»­ dá»¥ng.\r\nBáº£o máº­t cao: Do lÃ  báº£n tráº£ phÃ­, do váº­y báº¡n sáº½ Ä‘Æ°á»£c cáº­p nháº­t theme thÆ°á»ng xuyÃªn giÃºp tÄƒng cÆ°á»ng báº£o máº­t cÅ©ng nhÆ° fix lá»—i.\r\nCÃ²n ráº¥t nhiá»u Ä‘iá»ƒm ná»•i báº­t khÃ¡c cÃ¡c báº¡n cÃ³ thá»ƒ tham kháº£o táº¡i trang chá»§ Mythemeshop táº¡i Ä‘Ã¢y.\r\n\r\nCÃCH THAM GIA NHáº¬N QUÃ€ Táº¶NG MYTHEMESHOP\r\n\r\nTheme vÃ  Plugin Ä‘Æ°á»£c mÃ¬nh táº£i upload lÃªn Google Drive vÃ o ngÃ y 7/7/2017. File Ä‘Æ°á»£c mÃ¬nh download trá»±c tiáº¿p vÃ  upload nguyÃªn gá»‘c nÃªn hoÃ n toÃ n sáº¡ch.\r\n\r\nCÃ¡ch thá»©c tham gia:\r\n\r\nBÆ°á»›c 1: Like Fanpage cá»§a mÃ¬nh Truong Ken Dot Net.\r\nBÆ°á»›c 2: Chia sáº» bÃ i viáº¿t nÃ y lÃªn trang cÃ¡ nhÃ¢n Facebook cá»§a báº¡n á»Ÿ cháº¿ Ä‘á»™ cÃ´ng khai.\r\nBÆ°á»›c 3: Comment xuá»‘ng dÆ°á»›i Ä‘á»‹a chá»‰ email cá»§a báº¡n + link chia sáº» cá»§a báº¡n. Äá»ƒ láº¥y link bÃ i chia sáº» cá»§a báº¡n trÃªn Facebook. CÃ¡c báº¡n chá»‰ cáº§n click vÃ o má»‘c thá»i gian mÃ  bÃ i viáº¿t chia sáº» áº¥y Ä‘Æ°á»£c Ä‘Äƒng lÃªn, vÃ­ dá»¥ vá» má»‘c thá»i gian: Vá»«a xong, 1 phÃºt trÆ°á»›c, hÃ´m qua, 8 thÃ¡ng 5 nÄƒm 2017â€¦ Khi click vÃ o, Facebook sáº½ Ä‘Æ°a báº¡n Ä‘áº¿n link riÃªng cá»§a bÃ i Ä‘Äƒng Ä‘Ã³ vÃ  báº¡n copy nÃ³ lÃªn Ä‘Ã¢y.\r\nSau Ä‘Ã³ mÃ¬nh sáº½ kiá»ƒm tra vÃ  add Ä‘á»‹a chá»‰ gmail cá»§a cÃ¡c báº¡n vÃ o folder trÃªn Google Drive Ä‘á»ƒ cÃ¡c báº¡n download.\r\n\r\n Hiá»‡n táº¡i chÆ°Æ¡ng trÃ¬nh Ä‘Ã£ táº¡m dá»«ng. Tuy nhiÃªn cÃ¡c báº¡n hÃ£y ghÃ© thÄƒm website thÆ°á»ng xuyÃªn Ä‘á»ƒ cáº­p nháº­t cÃ¡c chÆ°Æ¡ng trÃ¬nh quÃ  táº·ng hay khÃ¡c. Náº¿u báº¡n nÃ o muá»‘n', 1, '2017-10-15 18:01:12'),
(9, 1, 1, 'aa', 'aa', 1, '2017-10-15 18:01:37'),
(10, 1, 1, 'wwwwwwwwwww', 'sssssssssssssssssssssssssssssssss', 0, '0000-00-00 00:00:00'),
(11, 1, 1, 'wwwwwwwwwwwww', 'wwwwwwwwwwwwwwwwwwwww', 2, '0000-00-00 00:00:00'),
(12, 1, 1, 'wwwwwwwwwwwww', 'wwwwwwwwwwwwwwwwwwwww', 2, '0000-00-00 00:00:00'),
(13, 1, 6, 'dddd', '<!DOCTYPE html>\r\n<html>\r\n<head>\r\n</head>\r\n<body>\r\n<p>dddddddddddddddÄ‘</p>\r\n</body>\r\n</html>', 2, '2018-01-22 18:56:29'),
(14, 1, 1, 'TrÆ°á»ng Besst', '<!DOCTYPE html>\r\n<html>\r\n<head>\r\n</head>\r\n<body>\r\n<h1>OC VKL</h1>\r\n<p>aaaaaaaaa</p>\r\n<ol>\r\n<li>aa<br />a</li>\r\n<li>a</li>\r\n<li>a</li>\r\n<li>a</li>\r\n<li>a</li>\r\n<li>a</li>\r\n<li>a</li>\r\n</ol>\r\n</body>\r\n</html>', 1, '2018-01-22 18:57:27'),
(15, 1, 1, 'áº£nh', '<!DOCTYPE html>\r\n<html>\r\n<head>\r\n</head>\r\n<body>\r\n<p><img src=\"http://sinhvienit.net/forum/anh_dai_dien/avatar615707_1.gif\" alt=\"ssss\" width=\"150\" height=\"117\" /></p>\r\n</body>\r\n</html>', 1, '2018-01-23 18:58:54');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `page_views`
--

CREATE TABLE `page_views` (
  `view_id` int(11) NOT NULL,
  `page_id` int(11) NOT NULL,
  `num_views` int(11) NOT NULL,
  `user_ip` text COLLATE utf32_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf32 COLLATE=utf32_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `page_views`
--

INSERT INTO `page_views` (`view_id`, `page_id`, `num_views`, `user_ip`) VALUES
(1, 10, 10, '127.0.0.1'),
(2, 3, 1, '127.0.0.1'),
(3, 14, 4, '127.0.0.1'),
(4, 15, 4, '127.0.0.1'),
(5, 12, 3, '127.0.0.1'),
(6, 11, 3, '127.0.0.1');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `users`
--

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL,
  `first_name` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `last_name` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(60) COLLATE utf8_unicode_ci NOT NULL,
  `pass` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
  `website` varchar(60) COLLATE utf8_unicode_ci DEFAULT NULL,
  `bio` text COLLATE utf8_unicode_ci,
  `avatar` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `user_level` tinyint(4) NOT NULL,
  `active` varchar(60) COLLATE utf8_unicode_ci DEFAULT NULL,
  `registration_date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `users`
--

INSERT INTO `users` (`user_id`, `first_name`, `last_name`, `email`, `pass`, `website`, `bio`, `avatar`, `user_level`, `active`, `registration_date`) VALUES
(1, 'Truong', 'Tran', 'congtruongvp97@gmail.com', '2615dcb7ce43f149d94674e71098f0ab9e608533', 'hinhnenmienphi.com', 'LiÃªn há»‡ facebook: fb.com/truongvp97 Ä‘á»ƒ xem thÃªm thÃ´ng tin  chi tiáº¿t :3', '8964675495a67648cd637a7.57846551.jpg', 2, NULL, '2017-10-15 12:59:00');

--
-- Chỉ mục cho các bảng đã đổ
--

--
-- Chỉ mục cho bảng `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`cat_id`);

--
-- Chỉ mục cho bảng `comments`
--
ALTER TABLE `comments`
  ADD PRIMARY KEY (`comment_id`),
  ADD KEY `page_id` (`page_id`),
  ADD KEY `comment_date` (`comment_date`);

--
-- Chỉ mục cho bảng `files`
--
ALTER TABLE `files`
  ADD PRIMARY KEY (`file_id`);

--
-- Chỉ mục cho bảng `options`
--
ALTER TABLE `options`
  ADD PRIMARY KEY (`option_id`);

--
-- Chỉ mục cho bảng `pages`
--
ALTER TABLE `pages`
  ADD PRIMARY KEY (`page_id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `cat_id` (`cat_id`),
  ADD KEY `post_on` (`post_on`),
  ADD KEY `position` (`position`);

--
-- Chỉ mục cho bảng `page_views`
--
ALTER TABLE `page_views`
  ADD PRIMARY KEY (`view_id`),
  ADD KEY `page_id` (`page_id`);

--
-- Chỉ mục cho bảng `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`),
  ADD UNIQUE KEY `email` (`email`),
  ADD KEY `registration_date` (`registration_date`),
  ADD KEY `first_name` (`first_name`),
  ADD KEY `last_name` (`last_name`),
  ADD KEY `pass` (`pass`);

--
-- AUTO_INCREMENT cho các bảng đã đổ
--

--
-- AUTO_INCREMENT cho bảng `categories`
--
ALTER TABLE `categories`
  MODIFY `cat_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT cho bảng `comments`
--
ALTER TABLE `comments`
  MODIFY `comment_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT cho bảng `files`
--
ALTER TABLE `files`
  MODIFY `file_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT cho bảng `options`
--
ALTER TABLE `options`
  MODIFY `option_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT cho bảng `pages`
--
ALTER TABLE `pages`
  MODIFY `page_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT cho bảng `page_views`
--
ALTER TABLE `page_views`
  MODIFY `view_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT cho bảng `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Các ràng buộc cho các bảng đã đổ
--

--
-- Các ràng buộc cho bảng `page_views`
--
ALTER TABLE `page_views`
  ADD CONSTRAINT `page_views_ibfk_1` FOREIGN KEY (`page_id`) REFERENCES `pages` (`page_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
